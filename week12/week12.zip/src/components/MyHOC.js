class MyHOC extends React.Component {



}

export default MyHOC